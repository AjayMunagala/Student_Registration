const express = require('express');
const bodyParser = require('body-parser');
const mysql = require('mysql');

const app = express();
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static(__dirname));
app.set('view engine', 'ejs');

app.get('/', (req, res) => {
    res.sendFile(__dirname + '/index.html');
});


const db = mysql.createConnection({
    host: "localhost",
    user: "root",
    password: "",
    database: "student1"
});
db.connect(function(error) {
    if(error) { console.log("DB is not connected"); }
    else{ console.log("DB is conncted successfully !") }
});

app.post('/', (req, res) => {
    var name = req.body.name;
    var email = req.body.email;
    var age = req.body.age;
    var gender = req.body.gender;
    var address = req.body.address;
    var password = req.body.password;
    var retypepassword = req.body.retypepassword;
    var pincode = req.body.pincode;

    
    if (password !== retypepassword) {
        return res.send("Password and Retype Password don't match.");
    }


    if (!/^\d{6}$/.test(pincode)) {
        return res.send("Invalid Pincode. It should be a 6-digit number.");
    }

    var sql =
        "INSERT INTO stu_reg(name, email, age, gender, address, password, retypepassword, pincode) VALUES(?,?,?,?,?,?,?,?);";
    db.query(
        sql,
        [name, email, age, gender, address, password, retypepassword, pincode],
        function (error, result) {
            if (error) throw error;
            res.redirect('/frontend');
        }
    );
});

app.listen(4000, function check(error) {
    if (error) {
        console.log("server is not connected");
    } else {
        console.log("server is up and running !");
    }
});
